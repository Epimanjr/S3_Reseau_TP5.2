package webclasses;
import java.util.*;

public class DateServeur implements MiniServlet {

    public String init(){

	return new String("<html>" + (new Date(System.currentTimeMillis())).toString() + "</html>");
    }
}
	
