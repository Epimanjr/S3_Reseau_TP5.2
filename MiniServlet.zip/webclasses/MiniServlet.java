package webclasses;

public interface MiniServlet {

    public String init();

}
